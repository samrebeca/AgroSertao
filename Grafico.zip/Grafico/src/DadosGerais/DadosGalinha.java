package DadosGerais;
public class DadosGalinha {
    private float a;
    private float b;
    private float c;
    private float d;
    private float e;
    private float f;

    public DadosGalinha(){
        a = 0;
        b = 0;
        c = 0;
        d = 0;
        e = 0;
        f = 0;
        

    }

    public float getA() {
        return a;

    }

    public void setA(float a) {
        this.a = a;
    }

    public float getB() {
        return b;
    }

    public void setB(float b) {
        this.b = b;
    }

    public float getC() {
        return c;

    }

    public void setC(float c) {
        this.c = c;
    }

    public float getD() {
        return d;

    }

    public void setD(float d) {
        this.d = d;
    }
    
    public float getE() {
        return e;

    }

    public void setE(float e) {
        this.e = e;
    }
    
    public float getF() {
        return f;

    }

    public void setF(float f) {
        this.f = f;
    }
    public float MediaGalinha(){
    return TotalGalinha()%3;
    }
    public float TotalGalinha(){
    return Lucrogalinha()+Gastogalinha();
    }

    public float Lucrogalinha(){
        return a*b*c;
    }
    
    public float Gastogalinha(){
    return f;
    }
    
    

}


