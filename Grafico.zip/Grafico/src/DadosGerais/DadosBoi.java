/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DadosGerais;

/**
 *
 * @author Lucas Canto
 */
public class DadosBoi {
    private float a;
    private float b;
    private float c;
    private float d;
    

    public DadosBoi(){
        a = 0;
        b = 0;
        c = 0;
        d = 0;
        

    }

    public float getA() {
        return a;

    }

    public void setA(float a) {
        this.a = a;
    }

    public float getB() {
        return b;
    }

    public void setB(float b) {
        this.b = b;
    }

    public float getC() {
        return c;

    }

    public void setC(float c) {
        this.c = c;
    }

    public float getD() {
        return d;

    }

    public void setD(float d) {
        this.d = d;
    }
    public float ResultadoBoiLucro(){
    return a*b*c;
    }
    public float ResultadoBoiTotal(){
    return ResultadoBoiLucro()+d;
    }
    public float ResultadoBoiPerca(){
    return d;
    }
    public float ResultadoBoiMedia(){
    return ResultadoBoiTotal()%3;
    }
    
}
