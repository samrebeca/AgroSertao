/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DadosGerais;
public class DadosVaca {
    private float a;
    private float b;
    private float c;
    private float d;
    private float e;
    private float f;

    public DadosVaca(){
        a = 0;
        b = 0;
        c = 0;
        d = 0;
        e = 0;
        f = 0;
        

    }

    public float getA() {
        return a;

    }

    public void setA(float a) {
        this.a = a;
    }

    public float getB() {
        return b;
    }

    public void setB(float b) {
        this.b = b;
    }

    public float getC() {
        return c;

    }

    public void setC(float c) {
        this.c = c;
    }

    public float getD() {
        return d;

    }

    public void setD(float d) {
        this.d = d;
    }
    
    public float getE() {
        return e;

    }

    public void setE(float e) {
        this.e = e;
    }
    
    public float getF() {
        return f;

    }

    public void setF(float f) {
        this.f = f;
    }
    
    public float resultado1(){
        return a*b*c;
    }
    public float resultado2(){
        return d*e;
    }
    public float resultadooficial(){
        return resultado1()+resultado2();
    }
    public float gastostotal(){
        return f;
    }
    public float total(){
        return resultado1()+resultado2()+gastostotal();
    }
    public float media(){
        return total()%3;
                
    }
   

}

