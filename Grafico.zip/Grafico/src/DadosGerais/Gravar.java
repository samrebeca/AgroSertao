/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DadosGerais;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


/**
 *
 * @author 20171104010033
 */
public class Gravar {

    public static void main(String[] args) throws IOException {
       

        try (FileWriter arq = new FileWriter("C:\\Users\\Lucas Canto\\Desktop\\teste.txt")) {
            PrintWriter gravarArq = new PrintWriter(arq);
    
            float passar = 12;
            gravarArq.printf("%f", passar);
            // Double.parseDouble("12.2");
            
        }

    }

   

}
