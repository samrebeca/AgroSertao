/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafico;


/**
 *
 * @author Lucas Canto
 */
public class Gastos {
    private String gastos;
    private int valor;
    public Gastos (String gastos,int valor){
        this.gastos=gastos;
        this.valor=valor;
    }
    public String getGastos(){
        return gastos;
    }
    public int getValor(){
        return valor;
    }
    
}
