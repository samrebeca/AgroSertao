
package Grafico;
import java.awt.Dimension;
import java.util.ArrayList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
public class Grafico1 {
    
public CategoryDataset createDataset(ArrayList<Gastos> listadegastos){
    
    DefaultCategoryDataset dataset = new  DefaultCategoryDataset();
    for(Gastos gastos: listadegastos)
        dataset.addValue(gastos.getValor(),gastos.getGastos(), " ");
    
    return dataset;
    
    
}

public JFreeChart createBarChart(CategoryDataset dataset){
    
JFreeChart graficoBarras = ChartFactory.createBarChart("GASTOS E LUCROS", " ", "VALOR EM R$", dataset, PlotOrientation.VERTICAL,true,false,false);
        return graficoBarras;
}
public ChartPanel criarGrafico(ArrayList<Gastos> listadegastos){
    
    CategoryDataset dataSet = this.createDataset(listadegastos);
    JFreeChart grafico = this.createBarChart(dataSet);
    ChartPanel painelDoGrafico = new ChartPanel(grafico);
    painelDoGrafico.setPreferredSize(new Dimension(400, 400));
    
    return painelDoGrafico;
}
}
